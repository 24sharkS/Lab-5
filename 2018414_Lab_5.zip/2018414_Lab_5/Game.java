import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

abstract class Tile {

  static Random r = new Random();

  abstract int get_Bite();
  abstract int get_bites();
  abstract void add_bites();
}

class Snake extends Tile {
  private static final int bite = r.nextInt(10) + 1;
  private static int t_bites = 0;
  int get_Bite(){
    return bite;
  }
  int get_bites(){
    return t_bites;
  }
  void add_bites(){
    t_bites++;
  }
}

class Vulture extends Tile {
  private static final int bite = r.nextInt(10) + 1;
  private static int t_bites = 0;
  int get_Bite(){
    return bite;
  }
  int get_bites(){
    return t_bites;
  }
  void add_bites(){
    t_bites++;
  }
}

class Cricket extends Tile {
  private static final int bite = r.nextInt(10) + 1;
  private static int t_bites = 0;
  int get_Bite(){
    return bite;
  }
  int get_bites(){
    return t_bites;
  }
  void add_bites(){
    t_bites++;
  }
}

class Tramp extends Tile {
  private static final int bite = r.nextInt(10) + 1;
  private static int t_bites = 0;
  int get_Bite(){
    return bite;
  }
  int get_bites(){
    return t_bites;
  }
  void add_bites(){
    t_bites++;
  }
}

class White extends Tile{
  int get_Bite(){
    return -1;
  }
  int get_bites(){
    return -1;
  }
  void add_bites(){
  }
}




class SnakeBiteException extends Exception{
  static Random r = new Random();
  private final static int bite = r.nextInt(10)+1;
  private static int t_bites=0;
  public SnakeBiteException(String s){
    super(s);
  }

  public static int getBite() {
    return bite;
  }

  public static int getT_bites() {
    return t_bites;
  }

  public static void add() {
    SnakeBiteException.t_bites++;
  }
}

class VultureBiteException extends Exception{
  static Random r = new Random();
  private final static int bite = r.nextInt(10)+1;
  private static int t_bites=0;
  public VultureBiteException(String s){
    super(s);
  }

  public static int getBite() {
    return bite;
  }

  public static int getT_bites() {
    return t_bites;
  }

  public static void add() {
    VultureBiteException.t_bites++;
  }
}


class CricketBiteException extends Exception{

  static Random r = new Random();
  private final static int bite = r.nextInt(10)+1;
  private static int t_bites=0;
  public CricketBiteException(String s){
    super(s);
  }

  public static int getBite() {
    return bite;
  }

  public static int getT_bites() {
    return t_bites;
  }

  public static void add(){
    CricketBiteException.t_bites++;
  }

}

class TrampolineException extends Exception{
  static Random r = new Random();
  private final static int bite = r.nextInt(10)+1;
  private static int t_bites=0;
  public TrampolineException(String s){
    super(s);
  }

  public static int getBite() {
    return bite;
  }

  public static int getT_bites() {
    return t_bites;
  }

  public static void add() {
    TrampolineException.t_bites++;
  }

}

class GameWinnerException extends Exception{
  public GameWinnerException(String s){super(s);}
}

class Game {
  static Random r = new Random();

  static void SettingUpTrack(int[] ar,ArrayList<Integer> E,int size){

    // randomising snake,vulture,cricket,trampoline & white.

    int max = size/4;
    for (int i = 0; i < 4; i++) {
      ar[i] = r.nextInt((max)+1);
    }
    ar[4] = size - (ar[0]+ar[1]+ar[2]+ar[3]+2);

    for (int i = 0; i < size-2; i++) {
      E.add(i,0);
    }

    for (int i = 0; i < ar[0]; i++){
      while(true){
        int id = r.nextInt(size-2);
        if(E.get(id)==0){
          E.set(id,1);
          break;
        }
      }
    }

    for (int i = 0; i < ar[1]; i++){
      while(true){
        int id = r.nextInt(size-2);
        if(E.get(id)==0){
          E.set(id,2);
          break;
        }
      }
    }

    for (int i = 0; i < ar[2]; i++) {
      while(true){
        int id = r.nextInt(size-2);
        if(E.get(id)==0){
          E.set(id,3);
          break;
        }
      }
    }

    for (int i = 0; i < ar[3]; i++) {
      while(true){
        int id = r.nextInt(size-2);
        if(E.get(id)==0){
          E.set(id,4);
          break;
        }
      }
    }

    for (int i = 0; i < E.size(); i++) {
      if(E.get(i)==0){
        E.set(i,5);
      }
    }

    E.add(0,0);
    E.add(0);
    ArrayList<Tile> t = new ArrayList<>(size);
    for(int i:E){
      if(i==5){
        t.add(new White());
      }
      else if(i==1){
        Tile tl = new Snake();
        t.add(tl);
      }
      else if(i==2){
        Tile tl = new Vulture();
        t.add(tl);
      }else if(i==3){
        Tile tl = new Cricket();
        t.add(tl);
      }
      else if(i==4){
        Tile tl = new Tramp();
        t.add(tl);
      }
    }
  }

  static int DiceRoll(){
    return r.nextInt(6)+1;
  }

  public static void main(String[] args) {
    int t_rolls = 0;
    int tile_no=1;

    Scanner sc = new Scanner(System.in);
    boolean ct = false;
    int tiles=0;

    System.out.println("Enter total number of tiles on the race track");

    while(ct==false){
      try{
        tiles = sc.nextInt();
        if(tiles<=0 || tiles<10){
          System.out.println("Please enter a positive integer value greater than equal to 10!!");
        }
        else{
         ct = true;
        }
      }
      catch(InputMismatchException e){
        System.out.println("Please enter a positive integer value greater than equal to 10!!");
        sc.next();
      }

    }

    System.out.println("Setting up the race track...");
    int[] ob = new int[5];

    ArrayList<Integer> Tile = new ArrayList<Integer>(tiles);
    ArrayList<Tile> t = new ArrayList<Tile>(tiles);

    SettingUpTrack(ob,Tile,tiles);

    System.out.println("Danger: There are "+ob[0]+","+ob[2]+","+ob[1]+" Snakes,Cricket and Vultures respectively on your track!");
    System.out.println("Danger: Each Snake, Cricket, and Vultures can throw you back by "+SnakeBiteException.getBite()+","+CricketBiteException.getBite()+","+VultureBiteException.getBite()+"number of Tiles respectively!");
    System.out.println("Good News: There are "+ ob[3]+" number of Trampolines on your track!");
    System.out.println("Good News: Each Trampoline can help you advance by "+TrampolineException.getBite()+" number of Tiles.");
    System.out.println("Enter the Player Name");
    sc.nextLine();
    String name = sc.nextLine();
    System.out.println("Starting the game with "+name+" at Tile-1");
    System.out.println("Control transferred to computer for rolling the Dice for Josh");
    System.out.println("Hit Enter to start the game");

    while(true){
      String ch = sc.nextLine();
      if(ch.equals("")){
        break;
      }
      else{
        System.out.println("Hit Enter to start the game");
      }
    }
    System.out.println("Game Started");

    Snake s = new Snake();
    Vulture v = new Vulture();
    Tramp trp = new Tramp();
    Cricket cr = new Cricket();

    while(true){

      //if we reach the final tile.
      if(tile_no==tiles){
        try{
          throw new GameWinnerException("\t"+name+" wins the race in "+t_rolls+" rolls!");
        }
        catch(Exception e){
          System.out.println(e.getMessage());
          System.out.println("\t"+"Total Snake Bites= "+s.get_bites());
          System.out.println("\t"+"Total Vulture Bites= "+v.get_bites());
          System.out.println("\t"+"Total Cricket Bites= "+trp.get_bites());
          System.out.println("\t"+"Total Trampolines Bites= "+cr.get_bites());
        }
        break;
      }
      else if(tile_no == 1){
          int st=0;
          while(true){
           st = DiceRoll();
           t_rolls++;
           if(st!=6){
             System.out.println("Roll-"+t_rolls+" "+name+"rolled "+st+" at Tile-"+tile_no+", OOPs you need 6 to start");
           }
           else{
             System.out.println("Roll-"+t_rolls+" "+name+"rolled "+6+" at Tile-"+tile_no+". You are out of the cage!You get a free roll");
             int z = DiceRoll();
             t_rolls++;
             System.out.println("Roll-"+t_rolls+" "+name+"rolled "+z+" at Tile-"+tile_no+", landed on Tile "+(tile_no+z));
             tile_no+=z;
             break;
           }

          }
      }
      else{
        while(true){
          int st = DiceRoll();
          t_rolls++;
          if(tile_no + st > tiles){
            System.out.println("[Roll-"+t_rolls+"] "+name+"rolled "+st+" at Tile-"+tile_no+", landed on Tile "+tile_no);
          }
          else{
            System.out.println("[Roll-"+t_rolls+"] "+name+"rolled "+st+" at Tile-"+tile_no+", landed on Tile "+(tile_no+st));
            tile_no+=st;
            break;
          }
        }
        int c = Tile.get(tile_no-1);
        switch(c){
          case 1:
            try{
              throw new SnakeBiteException("\tHiss...! I am a Snake, you go back "+s.get_Bite()+" tiles!");
            }
            catch (SnakeBiteException se){
              System.out.println(se.getMessage());
              s.add_bites();
              if (tile_no <= s.get_Bite()) {
                tile_no=1;
                System.out.println("\t"+name+" moved to Tile 1 as it can't go back further.");
              }
              else{
                tile_no -= s.get_Bite();
                System.out.println("\t"+name+" moved to Tile-"+tile_no);
              }
            }
           break;
          case 2:
            try{
              throw new VultureBiteException("\tYapping...! I am a Vulture, you go back "+v.get_Bite()+" tiles!");
            }
            catch (VultureBiteException se){
              System.out.println(se.getMessage());
              v.add_bites();
              if (tile_no <= v.get_Bite()){
                tile_no=1;
                System.out.println("\t"+name+" moved to Tile 1 as it can't go back further.");
              }
              else{
                tile_no-=v.get_Bite();
                System.out.println("\t"+name+" moved to Tile-"+tile_no);
              }
            }
            break;
          case 3:
            try{
              throw new CricketBiteException("\tChirp...! I am a Cricket, you go back "+cr.get_Bite()+" tiles!");
            }
            catch (CricketBiteException se){
              System.out.println(se.getMessage());
              cr.get_Bite();
              if (tile_no <= cr.get_Bite()) {
                tile_no=1;
                System.out.println("\t"+name+" moved to Tile 1 as it can't go back further.");
              }
              else{
                tile_no-=cr.get_Bite();
                System.out.println("\t"+name+" moved to Tile-"+tile_no);
              }
            }
            break;

            case 4:
            try{
              throw new TrampolineException("\tPingPong...! I am a Trampoline, you advance "+trp.get_Bite()+" tiles!");
            }
            catch (TrampolineException se){
              System.out.println(se.getMessage());
              trp.add_bites();
              if (tile_no + trp.get_Bite() > tiles){
                System.out.println("\t"+name+" moved to Tile "+tile_no+" as it can't move "+trp.get_Bite()+" steps ahead");
              }
              else{
                tile_no+=trp.get_Bite();
                System.out.println("\t"+name+" moved to Tile-"+tile_no);
              }
            }
           break;

          case 5:
            System.out.println("\tI am a White tile!");
            System.out.println("\t"+name+" moved to Tile-"+tile_no);
            int st =0;

            while(true){
              st = DiceRoll();
              t_rolls++;
              if(tile_no + st > tiles){
                System.out.println("[Roll-"+t_rolls+"] "+name+"rolled "+st+" at Tile-"+tile_no+", landed on Tile "+tile_no);
              }
              else{
                System.out.println("[Roll-"+t_rolls+"] "+name+"rolled "+st+" at Tile-"+tile_no+", landed on Tile "+(tile_no+st));
                tile_no+=st;
                break;
              }
            }
            break;
          default:
            break;
        }
      }



    }




  }
}
